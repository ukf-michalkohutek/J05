package sample;

import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import org.json.JSONArray;
import org.json.JSONObject;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.Arrays;
import java.util.HashMap;

public class Controller {
    static HashMap<String, Result> resultHashMap = new HashMap<>();

    static String conf;
    static String rec;
    static String dead;

    @FXML private TableView<Result> tableView;
    @FXML private TextField country;
    @FXML private TextField day;
    @FXML private TextField month;
    @FXML private TextField year;
    @FXML private Label output;

    String link = "https://covidapi.info/api/v1/country/SVK";
    String pick_cou;
    String ye;
    String mo;
    String d;

    @FXML protected void initialize() {

        downloadData();
    }

    void addResult(Result result) {
        ObservableList<Result> data = tableView.getItems();
        data.add(result);
    }

    void downloadData() {
            HttpClient client = HttpClient.newHttpClient();
            HttpRequest request = HttpRequest.newBuilder().uri(URI.create(link)).build();

        client.sendAsync(request, HttpResponse.BodyHandlers.ofString())
                .thenApply(HttpResponse::body)
                .thenApply(Controller::jsonParse)
                .join();

        for (String date : resultHashMap.keySet()) addResult(resultHashMap.get(date));
    }

    private static String jsonParse(String responseString) {
        JSONArray results = new JSONArray("[" + responseString + "]");
        JSONArray resultDates = results.getJSONObject(0).getJSONObject("result").names();
        String[] resultDatesSorted = new String[resultDates.length()];

        for (int i = 0; i < resultDates.length(); i++) { resultDatesSorted[i] = resultDates.get(i).toString(); }

        Arrays.sort(resultDatesSorted);

        for (String res : resultDatesSorted) {
            JSONObject result = results.getJSONObject(0).getJSONObject("result").getJSONObject(res);

            String date = res;
            String confirmed = String.valueOf(result.getInt("confirmed"));
            String deaths = String.valueOf(result.getInt("deaths"));
            String recovered = String.valueOf(result.getInt("recovered"));

            conf = confirmed;
            rec = recovered;
            dead = deaths;
            resultHashMap.put(res, new Result(res,confirmed,deaths,recovered));
        }
        return null;
    }

    @FXML
    protected void new_cou() {
        tableView.getItems().clear();
        resultHashMap.clear();
        pick_cou = country.getText();
        link = "https://covidapi.info/api/v1/country/"+ pick_cou;
        downloadData();
    }

    @FXML
    protected void choose_date() {
        pick_cou = country.getText();
        ye = year.getText();
        mo = month.getText();
        d = day.getText();
        link = "https://covidapi.info/api/v1/country/" + pick_cou + "/" + ye + "-" + mo + "-" + d;
        downloadData();
        output.setText("Confirmed: " + conf + " Recovered: " + rec +" Deaths: " + dead );
    }

    @FXML
    protected void global() //globálne
    {
        link = "https://covidapi.info/api/v1/global/count";
        downloadData();
        output.setText("Confirmed: " + conf + " Recovered: " + rec +" Deaths: " + dead );
    }
}