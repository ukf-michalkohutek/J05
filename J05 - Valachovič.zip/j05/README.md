# J05
- Country a Set
    - nastaví iný štát (skratka)
- Dátum a Exact Date
    - vypíše pod tlačidlá údaje pre dátum
    - ak nevyplníte country zobrazí údaje pre slovensko
- Global
    - vypíše pod tlačidlá globálne údaje
