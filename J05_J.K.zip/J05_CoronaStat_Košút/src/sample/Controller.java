package sample;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import org.json.JSONObject;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.TreeMap;

public class Controller {

    private static TreeMap<String,Result> data = new TreeMap<>();

    static String dateValue;
    static String countryValue;
    static boolean caughtError;

    @FXML private TableView<Result> tableView;
    @FXML private TextField country;
    @FXML private DatePicker date;
    @FXML private Button download;
    @FXML private Button clearDate;

    @FXML protected void initialize() {
        download.setOnAction(e->process());
        clearDate.setOnAction(e->date.setValue(null));
        process();
    }

    void process() {
        countryValue = country.getText();
        dateValue = null;
        if (date.getValue()!=null) dateValue = this.date.getValue().toString();
        String requestString = "";

        if (countryValue.equals("GLB")) {
            requestString+="https://covidapi.info/api/v1/global";
            if (dateValue==null) requestString+="/count";
            else requestString+="/"+dateValue;
        }
        else {
            requestString+="https://covidapi.info/api/v1/country/"+countryValue;
            if (dateValue!=null) requestString+="/"+dateValue;
        }

        downloadData(requestString);
        if (caughtError) {
            data.clear();
            tableView.getItems().clear();
            showError();
        }
        else displayData();
    }


    private void displayData() {
        tableView.getItems().clear();

        for (String key : data.keySet()) {
            tableView.getItems().add(data.get(key));
        }

        tableView.getSortOrder().add(tableView.getColumns().get(0));
    }


    private void downloadData(String requestString) {
        data.clear();

        HttpClient client = HttpClient.newHttpClient();
        HttpRequest request = HttpRequest.newBuilder().uri(URI.create(requestString)).build();

        client.sendAsync(request, HttpResponse.BodyHandlers.ofString())
                .thenApply(HttpResponse::body)
                .thenApply((country.getText().equals("GLB") && date.getValue()!=null) ? Controller::parseGlobalData : Controller::parseData)
                .join();
    }

    private static String parseData(String responseString) {
        caughtError = false;
        try {
            JSONObject result = new JSONObject(responseString).getJSONObject("result");

            for (String key : result.keySet()) {
                JSONObject day = result.getJSONObject(key);
                String confirmed = "" + day.getInt("confirmed");
                String deaths = "" + day.getInt("deaths");
                String recovered = "" + day.getInt("recovered");

                data.put(key, new Result(key, confirmed, deaths, recovered));
            }
        } catch (Exception e) {
            caughtError = true;
        }

        return null;
    }

    private static String parseGlobalData(String responseString) {
        JSONObject whole = new JSONObject(responseString);
        String date = whole.getString("date");

        JSONObject day = whole.getJSONObject("result");
        String confirmed = ""+day.getInt("confirmed");
        String deaths = ""+day.getInt("deaths");
        String recovered = ""+day.getInt("recovered");

        data.put(date, new Result(date, confirmed, deaths, recovered));

        return null;
    }

    private static void showError() {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Oops!");
        alert.setHeaderText("Wrong country or date.");
        alert.setContentText("Please enter a valid 3-letter ISO 3166 country code.\nPlease pick a valid date between 22nd January 2020 and last updated date.");

        alert.showAndWait();
    }
}


